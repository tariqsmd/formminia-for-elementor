<?php
/**
 * Form Header Partial
 *
 * @var array $args Partial arguments
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings  = $args['settings'];
$widget_id = $args['widget_id'];

// Build CSS classes
$container_classes = array(
	'mtforms-form-wrapper',
	'mtforms-container',
	'mtforms-skin-' . sanitize_html_class( $settings['skin'] ),
	'mtforms-layout-' . sanitize_html_class( $settings['layout'] ),
	'mtforms-input-style-' . sanitize_html_class( $settings['input_style'] ),
	'mtforms-button-style-' . sanitize_html_class( $settings['button_style'] ),
);

if ( ! empty( $settings['animation'] ) && $settings['animation'] !== 'none' ) {
	$container_classes[] = 'mtforms-animation-' . sanitize_html_class( $settings['animation'] );
}

if ( $settings['show_icons'] === 'yes' ) {
	$container_classes[] = 'mtforms-with-icons';
	$container_classes[] = 'mtforms-icon-' . sanitize_html_class( $settings['icon_position'] );
}

if ( $settings['show_labels'] !== 'yes' ) {
	$container_classes[] = 'mtforms-no-labels';
}

if ( ! empty( $settings['custom_css_class'] ) ) {
	$container_classes[] = sanitize_html_class( $settings['custom_css_class'] );
}

if ( $settings['button_width'] === 'full' ) {
	$container_classes[] = 'mtforms-button-full';
}

$container_classes[] = 'mtforms-align-' . sanitize_html_class( $settings['form_alignment'] );
$container_classes[] = 'mtforms-input-size-' . sanitize_html_class( $settings['input_size'] );

// Inline styles are handled by Elementor or can be injected here
?>

<div class="<?php echo esc_attr( implode( ' ', $container_classes ) ); ?>" id="<?php echo esc_attr( $widget_id ); ?>">
    <form id="form-<?php echo esc_attr( $widget_id ); ?>" class="mtforms-form" action="" method="POST" novalidate>
        <div class="mtforms-form-inner">